#Config for auditing_endpoint routine

#Supplied to authenticate client access to Tamr
uname = 'sa-python'
pword = 't@mr98'


#Host Name

#DevBox: awsagjnva1210.jnj.com
#SandBox: awsagjnva1203.jnj.com, '10.37.79.203'
#Production: awsagjnva1213.jnj.com
hostIn = 'awsagjnva1210.jnj.com'

#Base Path for tamr_api
base_pathIn = '/api/'

authorize = {"uname" : uname, 
            "pword": pword, 
            "hostIn": hostIn, 
            "base_pathIn": base_pathIn}




categorization_projects = [
    "All SKUs Category Product Hierarchy",
    "APAC - Customer Hierarchy - Naveen",                           
    "Asia-Pacific Channel Hierarchy",                            
    "CLS Transporter Name Standardization",                           
    "CLS Categorisation Project1",                            
    "Scent Categorization",                            
    "POM APAC POC",                            
    "Form Categorization V2"
]

schema_mapping_projects = [
    "APAC_Dataset_FG_Input",                      
    "Asia-Pacific Customer Hierarchy Output",                      
    "CatMan Schema Mapping - LATAM",                       
    "CIW_Dataset_FG_Input",                       
    "Consumer Product GR Output",                       
    "FG_Attribute_Input",                       
    "Mercury_Dataset_FG_Input"                       
]

golden_record_projects = [
    "Channel Golden Record Payal",                           
    "Consumer Product Golden Records V2",                           
    "Finished_Goods_Golden_Records",                           
    "JM_Golden_Records"                         
]

mastering_projects = [
    "Channel Test Mastering- Paypal",
    "Consumer Product Mastering V2",
    "Finished_Goods_Mastering",
    "IE_Germany",
    "IE_Russia",
    "IE_UK",
    "Consumer Product and Finished Goods Mastering",                       
    "Inside-Out EMEA",
    "Inside-Out EMEA V2",
    "Internal_External_Tamr_Copy",
    "Internal_External_Within_Brand",
    "IRE Mastering 2",                       
    "Market_Mirror_Mastering",                       
    "Product Key Mastering- V2",                       
    "UPCync"            
]
one_master = ["Product Key Mastering- V2"]



