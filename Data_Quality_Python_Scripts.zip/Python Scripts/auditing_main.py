#!/usr/bin/env python
# coding: utf-8


import auditing_include

'''

Created by Nolan Raghu, Last Edited 8/5/2020
README

Final Classification Path
['Indirect Accounts', 'Distributor', 'Distributor (Cosmetic Store)']
Category Path
['Indirect Accounts', 'Distributor', 'Distributor (Cosmetic Store)']
Final Classification Path
['Direct Accounts', 'Mass / Hyper / Super', 'Hypermarket']
Category Path
['Direct Accounts', 'Mass / Hyper / Super', 'Hypermarket']

Description:
    This script pulls record, categorization, and model confidence data from J&J Tamr projects
    
    Categorization Attributes (data will also have project-specific types)
        tag
        datasetId
        transactionId
        taxonomyId
        categoryId: Id of categoryPath
        type: usually Manual
        createdBy: tamr username that uploaded data or made correction
        createdAt: Date classification made
        score: 
        categoryPath: classification of record in the taxonomy
        tamr_id: unique tamr id
        origin_source_name: the original .csv   
        origin_entity_id: Above's id
        manualClassificationId: Id of tamr suggestion unless a user overrides, then its the user's cateogory id
        manualClassificationPath: Name of above
        suggestedClassificationId: Tamr-suggested Id
        suggestedClassificationPath: Name of above
        suggestedClassificationTierConfidences: Confidence of each category tier (i.e. [Object/Silverware/Fork] = [.934/.986/.921])
        suggestedClassificationConfidence: Bottom tier's confidence ('Fork' in the above example)
        suggestedClassificationIdAboveThreshold:  If a threshold is used, this is the Id that has a confidence above the threshold
        suggestedClassificationPathAboveThreshold
        suggestedClassificationConfidenceAboveThreshold
        ruleOverrideClassificationId
        ruleOverrideClassificationPath
        ruleTrainingClassificationId
        ruleTrainingClassificationPath
        finalClassificationId: Same as categoryId
        finalClassificationPath: Same as categoryPath

        ####THE FOLLOWING ARE DATA TYPES OF RECORDS #####
        #### They will change depending on the project ##

        ## This one was taken from the Naveen project #####
        Sales Group (CV)
        Sales Org Description
        Customer Group Description
        Global Customer Number
        Sales Office (CV)
        Channel
        Sales Organization
        Customer Number
        Banner in Format Key (CV)
        Distribution Channel
        Banner Key (CV)
        Channel Key (CV)
        Banner
        Customer Number Description
        Parent Customer
        Sub Channel
        Regional Customer
        Parent Customer Key (CV)
        Go To Model Key (CV)
        Customer Group (CV)
        Go To Model
        Sub Channel Key (CV)
        Sales Group Description
        Distribution Channel Description
        Attribute 6
        Banner in Format
        Sales Office Description
        Customer Number - Trigram
        Column1

        
        ############## RECORD DATA END ###################

        ##Custom categories created by script

        datePulled: The date this audit was conducted
        changedRecord: True if finalClassification != suggestedClassification (i.e., if a human overrode the categorization)
    
    Mastering Attributes (data will also have project-specific types)
        persistentId: unique Cluster Id
        name: Name of cluster
        recordCount: # of clusters
        totalSpend
        clusterVerificationCounts
        averageLinkage: Average linkage between pairings in clusters
        recordIds: Multiple types of record Ids 
        sourceId: Name of the dataset
        entityId: tamr Id
        originSourceId: Name of data's original .csv file
        originEntityId: Client-side ID (used to match with records upstream)

        clusterName
        suggestedClusterId
        verifiedClusterId
        verificationType
        realRecordIds: client-side Record Ids (the same as those put in )
        neverVerified
        unverified
        locked
        movableDisagree: Non-published records whose suggestions were denied
        movableAgree: Non-published records whose suggestions were accepted
        suggestDisagree: Records whose suggestions were denided
        suggestAgree: Records whose suggestest were accepted
        totalRecords: Sum of previous 7 points
        datePulled: Date the script was run
        Upload Date: Date the origin dataset was last updated
        

        


BEFORE RUNNING:
    1. Ensure 'auditing_config.ipynb' and 'auditing_include.ipynb' is in root directory.
        They can be replaced with 'import <file>.py' if converted from .ipynb

To Run:
    1. Change the parameters 'mode' and 'project_types' below as desired
    2. Run this script
    
To Add/Remove projects being audited:
    Add/Remove the project's name in quotes in the  'categorization_projects' array in the config
    
To change user credentials or host:
    See 'auditing_config' and change the appropriate variables


'''
###   Modes:
#    Categorization
#       'raw' - Export data in most raw form, including project-specific data (default)
#       'tidy' - Mainly Meta-Data and confidence data (default)
#       'corrections' - Only corrections (Where expert opinion overrides Tamr)    
#    Mastering
#       'raw' - Export data in most raw form, uncluding project-specific data (default)
#       'tidy' - Mainly metadata and confidence data (defauly)
#       'corrections' - Only corrections (Where the verified Cluster was not Suggested Cluster)
#   Other: (multiple can be selected at once)
#       'refresh' - Refreshes datasets before auditing
#           Note: Refreshing datasets is the most time-consuming part of the script. However,
#               it must be done for datasets that have not been profiled. The recommended use of this script is to 
#               run a 'refresh' audit if a new project has been added that has not been profiled, and otherwise leave this
#               parameter false.
#       'log' - Log process for debugging

#
#   project_types
#       both - all project types (default)
#       categorization
#       mastering
#       one_mastering - only one masterting (for quicker testing)



##CHANGE PARAMETERS BELOW by editing string after the colon
mode = {
    "categorization": "raw",

    "mastering": "raw",

    "other": {

        'refresh': True,

        'log': False

    }
}




#CHANGE PROJECT TYPE HERE:
project_types = "categorization"


auditing_include.auditTamr(mode, project_types)
