#last edited by Kyle Fenske. Changed Date and Time code to include time.
#!/usr/bin/env python
# coding: utf-8

######################################################################################

#Driver for tamr Audit (a.k.a run this)
import auditing_config #Ensure 'config.auditing.py' is in root directory")
from tamr_unify_client import Client
from tamr_unify_client.auth import UsernamePasswordAuth
import pandas as pd
from datetime import datetime
import json
import urllib.parse
import io
import os
import logging
import re


#####  HELPER FUNCTIONS ###########

#Current path length from main -> data is 3

#####Creates folder directors for out files
def pathOrganizing(path):
    k = not(os.path.isdir(path))
    if k:
        os.makedirs(path)
    os.chdir(path)
    return k
        

###A useful shortcut for typing os.chdir(os.pardir) 3 times
def goToParentDir():
        os.chdir(os.pardir)
        os.chdir(os.pardir)
        os.chdir(os.pardir)

def fail(projectName):
    logging.warning(f"Audit of project {projectName} has aborted")
    goToParentDir()
    return -1

#Curently deprecated. It was an attempt to remove illegal characters
def sanitizeName(name):
    def matchFun(matchObject):
        if(
            matchObject.group(0) == '*' or matchObject.group(0) == '<' or matchObject.group(0) == '>'   
        ): 
            return ""
        elif(
            matchObject.group(0) == '/' or matchObject.group(0) == '|' or matchObject.group(0) == ':'
            or matchObject.group(0) == '\\'
        ): 
            return "-"
        elif (matchObject.group(0) == '"'): return 'in.'
        elif (matchObject.group(0)[0] == '?'): return '(Unknown)'
        else: #Occurs when quotes appear
            return matchObject.group(0)[1:-1]

    fileCol = re.sub(r"\".*?\"|[/*|:<>]|\?+|\\|\"", matchFun, str(name))
    return re.sub(r'[\x00-\x7F]+','(X)', fileCol)

########################HELPER END##############

#####Authorization Statements########
# uname/pword/hostIn/base_pathIn are all stored in auditing_config.py
auth = auditing_config.authorize

tamr_api = Client(UsernamePasswordAuth(auth["uname"],auth["pword"]),host = auth["hostIn"],base_path=auth["base_pathIn"])
tamr = Client(UsernamePasswordAuth(auth["uname"],auth["pword"]),host=auth["hostIn"])
current_projects = {
    "categorization": [], 
    "mastering": [], 
    "schema mapping": [],
}


################MAIN FUNCTIONS####################

## Makes a list of all project names of a given project type
def generateProjectNames():
    modeDict = {
        'DEDUP': "mastering",
        "CATEGORIZATION": "categorization",
        "SCHEMA_MAPPING_RECOMMENDATIONS": "schema mapping"
    }
    for p in tamr.projects:
        current_projects[modeDict[p.type]].append(p.name)
        

##Finds the  Dataset Id, Recipe Id, Taxonomy Id, and the Unified Dataset for Categorization Projects
def loadProject(projectName):
    project = tamr.projects.by_name(projectName)
    project = project.as_categorization()
    projId = project.relative_id
    try:
        unified_dataset = project.unified_dataset()
    except: 
        return [0,0,0,-1]
    #finds taxname
    try:
        taxName = project.taxonomy().name
        taxId = json.loads(tamr_api.get(f"taxonomy/taxonomies/{taxName}").text)['documentId']['id']
    except:
        return [0, 0, -1, 0]

    #finds recipeId
    try:
        k  = tamr_api.get(f'recipe/{projId}').text
        j = json.loads(k)
        recipeId = j["data"]["steps"][2]["id"]
    except:
        return [0, -1, 0, 0]

    #datasetId = tamr.datasets.byName(projectName)
    try:
        qDataSetString = f'versioned/v1/datasets?filter=name%3D%3D{urllib.parse.quote(unified_dataset.name)}'
        datasetId = int(json.loads(tamr_api.get(qDataSetString).text)[0]['relativeId'][9:])
    except:
        [-1, 0, 0, 0]


    return [datasetId, recipeId, taxId, unified_dataset]


#### Finds the upload date for Mastering Projects
def getUploadDate(dsName):
    dsJson = json.loads(tamr_api.get(f'dataset/datasets/named/{dsName}').text)
    return str(datetime.fromtimestamp(dsJson["lastModified"]["timestamp"]))[0:10]

    #["lastModified"]["timestamp"]
    #["created"]["timestamp"]


##### Driver for Categorization Projects. 
def auditTamrCategorization(projectName, mode, other):
    
    if other["log"]:
        logging.info(f"Audit start for categorization project:[{projectName}] mode:[{mode}]")
    if projectName[-1] == " ":
        projectNameP = projectName[:-1]
    else:
        projectNameP = projectName
    path = os.path.abspath(f"categorization/{mode}/{projectNameP}")
    pathOrganizing(path)
    
    dataset_id, recipe_id, tax_id, unified_dataset = loadProject(projectName)

    if (tax_id == -1 or dataset_id == -1 or recipe_id == -1 or unified_dataset == -1):
        idErrDict = ["unified dataset id",  "user logging recipe", "taxonomy", "unified dataset"]
        ids = [dataset_id, recipe_id, tax_id, unified_dataset]
        idErrStr = ", ".join([idErrDict[x] for x in range(4) if (ids[x] == -1)])

        logging.warning(f"Project {projectName} failed due to lacking a {idErrStr}")
        return fail(projectName)

    if other["log"]:
        logging.info(f"User Data found for project {projectName}")

    r = tamr_api.get(f'procurement/datasets/{dataset_id}/categorizations?tag={recipe_id}&taxonomyId={tax_id}')

    df = pd.DataFrame(json.loads(r.text),dtype = object)
    df[0:8].to_csv(f"User Data sample for {projectName}.csv")
    ds = tamr.datasets.by_name(f'{unified_dataset.name}_classifications_with_data')

    if (other["refresh"]):
        ds.refresh()

    recs = pd.DataFrame([r for r in ds.records()])
    recs[0:8].to_csv(f"Record Data sample for {projectName}.csv")
    try:
        joined = df.merge(recs, left_on = 'transactionId', right_on = 'tamr_id')
    except KeyError:
        logging.warning(f"tamr_id not found on records in project {projectName}")
        return fail(projectName)

    today = datetime.today().strftime("%c")


    columnNames = [
        'User', 
        'Created At', 
        'Tamr Classification', 
        'Final Classification', 
        'Model Confidence', 
        'tamr_id', 
        'Project Name'
    ]
    loopArray = []
    ##Go To Model,Channel,Sub Channel
    deliver = pd.DataFrame()
    
    
    
    if(mode == 'tidy'):
        for _, row in joined.iterrows():
            tamrClassification = row.suggestedClassificationPath[-1]
            finalClassification = row.finalClassificationPath[-1]
            outDate = datetime.fromtimestamp(row.createdAt).strftime("%c")
            outRow = [
                row.createdBy, outDate, tamrClassification, finalClassification,                     
                row.suggestedClassificationConfidence, row.tamr_id, projectName
            ]
            loopArray.append(outRow)
        deliver = pd.DataFrame(data=loopArray, columns=columnNames)

    
    elif(mode == 'corrections'):
        for _, row in joined.iterrows():
            tamrClassification = row.suggestedClassificationPath[-1]
            finalClassification = row.finalClassificationPath[-1]
            if(tamrClassification != finalClassification):
                outDate = datetime.fromtimestamp(row.createdAt).strftime("%c")
                outRow = [
                    row.createdBy, outDate, tamrClassification, finalClassification,                           
                    row.suggestedClassificationConfidence, row.tamr_id, projectName
                ]
                loopArray.append(outRow)
        deliver = pd.DataFrame(data=loopArray, columns=columnNames)
        
    elif(mode == "raw"):
        deliver = pd.DataFrame(joined)
        deliver["createdAt"] = deliver["createdAt"].apply(lambda x: str(datetime.fromtimestamp(x).strftime("%c")))

        
    deliver["datePulled"] = deliver.apply(lambda row: today, axis=1)
    deliverPath = f'Audit of {projectName}_{mode}.csv'   
    deliver["changedRecord"] = deliver["suggestedClassificationPath"] != deliver["finalClassificationPath"]

    print(f'Project {projectName} has completed a {mode} audit\n')


    deliver.to_csv(deliverPath)
    goToParentDir()


    if other["log"]:
        logging.info(f"Audit finished for categorization project:[{projectName}] mode:[{mode}]")




## Driver for Mastering Projects
def auditTamrMastering(projectName, mode, other):



    if other["log"]:
        logging.info(f"Audit start for mastering project:[{projectName}] mode:{mode}")
    path = os.path.abspath(f"mastering/{mode}/{projectName}")
    pathOrganizing(path)
    
    project = tamr.projects.by_name(projectName)
    project = project.as_mastering()
    today = datetime.today().strftime("%c")

    unified_dataset = project.unified_dataset()

    uData = tamr.datasets.by_name(f'{unified_dataset.name}_dedup_published_clusters_with_data') 
    if (other["refresh"]):
        op = uData.refresh() 
        assert op.succeeded

    uDataRecs = pd.DataFrame([r for r in uData.records()])
    uDataRecs.iloc[0:8].to_csv(f"Sample ClusterData of {projectName}.csv")
    #print(f"uData: {uDataRecs["originEntityId"]}  {type(uDataRecs["originEntityId"])}")

    
    uStats = tamr.datasets.by_name(f'{unified_dataset.name}_dedup_published_cluster_stats')
    if (other["refresh"]):
        op = uStats.refresh()
        assert op.succeeded

    uStatsRecs = pd.DataFrame([r for r in uStats.records()])
    uStatsRecs.iloc[0:8].to_csv(f"Sample ClusterStats of {projectName}.csv")
    #print(f"uStats: {uStatsRecs["recordIds"]} \n {type(uStatsRecs["recordIds"])}")

    try:
        joined = uStatsRecs.merge(uDataRecs, on = 'persistentId', how = 'outer') 

        '''The following traits are being pulled from joined by whatIWant:
                persistentId - In order to merge (stats, data)
                originEntityId - In order to match upstream (data)
                clusterName - Name Tamr Believes (data)
                finalClassification - classification according to pairings set(data)
                name - (stats)
                averageLinkage - (stats)
                clusterVerificationCounts - (stats)
                    Displayed seperately as neverVerified, unverified, locked, movableDisagree, 
                    movableAgree, suggestDisagree, suggestAgree
                recordIds - (stats)


        '''
        def getIds(row):
            return " ".join(k["originEntityId"] for k in row["recordIds"])

        joined["realRecordIds"] = joined.apply(lambda row: getIds(row), axis=1)

        counts = ["neverVerified", "unverified", "locked", "movableDisagree", "movableAgree", "suggestDisagree", "suggestAgree"]

        if "clusterVerificationCounts" in joined:
            for count in counts:
                joined[count] = joined.apply(lambda row: row["clusterVerificationCounts"][count], axis=1)
            #cols = cols.drop("clusterVerificationCounts")
            joined["totalRecords"] = sum([joined[count] for count in counts])  

        joined["datePulled"] = joined.apply(lambda row: today, axis=1)


        if(mode != 'raw'):
            whatIWant = [
                "persistentId",
                "realRecordIds", 
                "clusterName", 
                "finalclassificationpath",
                "name", 
                "averageLinkage", 
                "clusterVerificationCounts", 
                "suggestedClusterId",
                "verifiedClusterId",
                "originSourceId"
            ]


            whatIGet = []
            for x in whatIWant:
                if x in joined:
                    whatIGet.append(x)

            cols = joined[whatIGet].copy()
            #Need to fix
            if (mode == "corrections"):
                cols = cols.drop(cols[cols["suggestedClusterId"] == cols["verifiedClusterId"]].index)
        elif(mode == 'raw'):
            cols = joined

        cols["Upload Date"] = cols.apply(lambda row: getUploadDate(row["originSourceId"]), axis=1)
        print(f"Data types: {cols.columns}")
        cols.to_csv(f'Audit of {projectName} on {mode}.csv')


    except KeyError:
        logging.warning(f'The mastering project {projectName} has encountered a KeyError. This is probably due to record data not containing a tamr_id column')
        return fail(projectName)

    goToParentDir()
    print(f'Project {projectName} has completed a {mode} audit\n')

    if other["log"]:
        logging.info(f"Audit finished for mastering project:[{projectName}] mode:[{mode}]")



######## DRIVER FUNCTIONS (Called by auditing_main.py) #########
###Driver Helper functions 
def categorization(mode):
    for project in current_projects["categorization"]:
        auditTamrCategorization(project, mode["categorization"], mode["other"])
            
def mastering(mode):
    for project in current_projects["mastering"]:
        auditTamrMastering(project, mode["mastering"], mode["other"])
            
def both(mode):
    categorization(mode)
    mastering(mode)

def one_mastering(mode):
    auditTamrMastering("Product Key Mastering- V2", mode["mastering"], mode["other"])
    
    
## Main Driver. Called by auditing_main.py
def auditTamr(mode, project_types):
    generateProjectNames()
    
    proj_switch = {
        "categorization": categorization,
        "mastering": mastering,
        "one_mastering": one_mastering,
        "both": both
    }
    if(mode["other"]["log"]):
        today = datetime.today().strftime("%c")
        logging.basicConfig(
            filename=f'audit_{project_types} on {today}.log',
            level=logging.INFO
        )
    func = proj_switch.get(project_types, lambda: "Invalid Mode")
    func(mode)

