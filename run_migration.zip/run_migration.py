#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import datetime
import os
import shutil
import sys
import yaml

from MigrationClient import MigrationClient


def logger(msg, *args):
    print("{0} {1}".format(datetime.datetime.now(), msg))
    for arg in args:
        print(arg)
    sys.stdout.flush()


### FROM_TAMR RELATED FUNCTIONS
def valid_save_location(migrator):
    """Check if the save location provided is valid:
    If the path doesn't exist, will attempt to make the folder.
    Will place a small file to test if have write permissions
    """
    if not os.path.isdir(migrator.cfgdir):
        os.makedirs(migrator.cfgdir)
    testfile = os.path.join(migrator.cfgdir, migrator.cfgfile)
    if os.path.isfile(testfile):
        logger('WARNING: file exists and will be overwritten: {}'.format(testfile))
    try:
        open(testfile, 'w').write('Testing if file is writeable.')
    except Exception as e:
        print('{} is not writeable:\n{}'.format(testfile, e))
        sys.exit(0)

def preimport_validation(migrator, options, projects, modules):
    """Run various validation checks before importing into target instance
    """
    ### VALIDATION TEST 1
    ###   For mastering/classification/schema projects only...
    ###      If the target project does not exist, the target unified dataset cannot exist either.
    ###      If the target project does exist, the target unified dataset must exist, too.
    m_c_s_flag = options.get('TARGET_PROJECT_TYPE') in ['DEDUP', 'CATEGORIZATION', 'SCHEMA_MAPPING_RECOMMENDATIONS']
    project_exists = options.get('NEW_PROJECT_NAME') in list(projects.values())
    try:
        migrator.tamr.default_client.datasets.by_name(migrator.project_dtls.get('target_unifiedDatasetName'))
        ud_exists = True
    except KeyError:
        ud_exists = False
    if m_c_s_flag:
        assert (project_exists and ud_exists) or not (project_exists or ud_exists), \
            "\n  Inconsistent state for target project and unified dataset.\n"\
            f"      target project exists: {project_exists}\n"\
            f"      target unified dataset exists: {ud_exists}\n"\
            "  If the project does not exist, it may have been previously deleted from the target instance.  You can "\
            "either manually delete the orphaned unified dataset or specify a new target project name using the "\
            "\"NEW_PROJECT_NAME\" configuration parameter.\n"\
            "  If the project does exist, you will need to manually create the unified dataset before continuing."
    return

def get_valid_project(project_name, all_projects, all_project_names):
    """Check if the project name is valid
    Are there >1 projects with that name? Don't think this case can happen
    Is there 1 project with that name? Raise error if not for project not found.
    """

    # Removing this check since GRs are modules not projects
    """# make sure the provided project name actually exists
    if project_name not in all_project_names.values():
        raise Exception(
            "Project name not found. Available projects are {}".format(list(all_project_names.values())))
    """
    # DO: i don't think this case can happen, multiple projects with identical names
    project_to_be_migrated = list(filter(lambda x: x[0] == project_name, all_projects.values()))

    if len(project_to_be_migrated) > 1:
        raise Exception("There is more than one project with this name")
    elif len(project_to_be_migrated) == 0:
        return
    else:
        project_to_be_migrated = project_to_be_migrated[0]
        return(project_to_be_migrated)


### TO_TAMR RELATED FUNCTIONS
def read_image_metadata(migrator, options):
    """This function wraps a function that reads the migration config file.
    We need to set and return some variables.  We also need to update the migration object to distinguish between source
    and target values for things like the unified dataset name, source list name, etc
    This function needs to set and return the following variables:
      <variable name> : <M|C|SM|GR> - <description>
      projType : M|C|SM|GR - type of project that is stored in the migration config file
      name : M|C|SM|GR     - "old" name of the project in the source instance
      projName : M|C|SM|GR - "new" name of the project in the destination instance
      input_cfg : M|C|SM   - list of source dataset names with metadata in the migration config file
      input_data : M|C|SM  - list of source dataset names with data files in the migration package
      has_ud_cfg : M|C|SM  - boolean flag indicating if the migration config file contains unified dataset metadata
      has_source_list : GR - boolean flag indicating if the migration package contains a GR source list file
      has_overrides : GR   - boolean flag indicating if the migration package contains a GR overrides file
    """
    # This function initializes several attributes in the migrator object and returns the project type
    # Note that we are passing the target project type here, presumably to allow us to allow for migrating between
    #    project types...
    projType = migrator.read_migration_config(project_type=options.get('TARGET_PROJECT_TYPE'))

    tempdir = os.path.join(migrator.cfgdir, migrator.pkgsubdir)
    name = migrator.project_dtls.get('name') or migrator.module_dtls.get('displayName')
    input_cfg = [x.get('name') for x in migrator.input_dataset_dtls]
    input_data = [x for x in os.listdir(tempdir) if x != 'migration_config.json']
    has_ud_cfg = migrator.unified_dataset_dtls is not None
    projName = options.get('NEW_PROJECT_NAME')
    has_source_list = f"{name}_source_list" in input_data
    has_overrides = f"{name}_golden_records_overrides" in input_data

    """Here we update the migrator object to distinguish between important source/target differences"""
    if len(migrator.project_dtls) > 0:
        migrator.project_dtls['target_name'] = projName
        udName = options.get('UD_NAME') or projName + '_unified_dataset'
        migrator.project_dtls['target_unifiedDatasetName'] = udName
    else:
        migrator.module_dtls['target_name'] = projName
        migrator.module_dtls['target_source_list'] = f"{projName}_source_list"
        migrator.module_dtls['target_overrides'] = f"{projName}_golden_records_overrides"
        migrator.module_dtls['target_grs'] = f"{projName}_golden_records"
        udName = ""

    logger('- Importing project: {}'.format(projName))
    logger('  with UD name: {}'.format(udName))
    logger('  as type: {}'.format(projType))

    return projType, name, input_cfg, input_data, has_ud_cfg, projName, has_source_list, has_overrides


### IMPORT / EXPORT FUNCTIONS
def export_schema_mapping(migrator, projName, options):
    # Apply settings to the migrator function
    # Schema mapping project
    migrator.migrate_mastering_from(
        projName=projName,
        # take all data by default
        include_source_data=(options.get('INCLUDE_DATA_FILES'), options.get('INCLUDE_DATA_FILES')),
        include_source_config=options.get('INCLUDE_SOURCE_TO_UNIFIED_MAPPING'),
        include_ud_config=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS')
    )
    migrator.write_migration_config()


def export_dedup(migrator, projName, options):
    # Apply settings to the migrator function
    # Mastering project
    migrator.migrate_mastering_from(
        projName=projName,
        # take all data by default
        include_source_data=(options.get('INCLUDE_DATA_FILES'), options.get('INCLUDE_DATA_FILES')),
        include_source_config=options.get('INCLUDE_SOURCE_TO_UNIFIED_MAPPING'),
        include_ud_config=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS'),
        include_dnf=options.get('DEDUP_INCLUDE_DNF'),
        include_labels=options.get('DEDUP_INCLUDE_LABELS'),
        include_model=options.get('DEDUP_INCLUDE_MODEL'),
        include_locks=options.get('DEDUP_INCLUDE_LOCKS')
    )
    migrator.write_migration_config()


def export_classification(migrator, projName, options):
    # Apply settings to the migrator function
    # classification project
    migrator.migrate_classification_from(
        projName=projName,
        # take all data by default
        include_source_data=(options.get('INCLUDE_DATA_FILES'), options.get('INCLUDE_DATA_FILES')),
        include_source_config=options.get('INCLUDE_SOURCE_TO_UNIFIED_MAPPING'),
        include_ud_config=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS'),
        include_taxonomy=options.get('CLASS_INCLUDE_TAXONOMY'),
        include_categories=options.get('CLASS_INCLUDE_CATEGORIES')
    )

    migrator.write_migration_config()

def export_gr(migrator, projName, options):
    # Apply settings to the migrator function
    # GR project
    migrator.migrate_gr_from(
        moduleName=projName,
        include_source_list=options.get('GR_INCLUDE_SOURCE_LIST'),
        include_overrides=options.get('GR_INCLUDE_OVERRIDES')
    )

    migrator.write_migration_config()


def import_schema_mapping(migrator, options, projName, all_project_names, name, input_cfg, input_data, has_ud_cfg):
    # Extract a schema mapping project
    msg = (
        "Image file contains:\n"
        "   project name: {}\n"
        "   input data config: {}\n"
        "   input data: {}\n"
        "   unified dataset config: {}\n"
    ).format(name, input_cfg, input_data, has_ud_cfg)
    print(msg)

    migrator.migrate_mastering_to(
        create_project=projName not in all_project_names.values(),
        update_source_datasets_def=options.get('INCLUDE_SOURCE_DATA_SCHEMA') and len(input_cfg),
        update_source_data=(
            options.get('INCLUDE_DATA_FILES') and len(input_data),
            options.get('TRUNCATE_OLD_DATA'),
            options.get('TRUNCATE_OLD_DATA')
        ),
        update_unified_dataset_def=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS') and has_ud_cfg,
        update_dnf=False,
        update_pair_labels=(False, False),
        update_model=False,
        update_locks=(False, False),
        run_pairs=False,
        run_trainPredictCluster=False,
        run_predictCluster=False
        )


def import_dedup(migrator, options, projName, all_project_names, name, input_cfg, input_data, has_ud_cfg):
    # Apply settings to the migrator function
    # Mastering project
    has_dnf = migrator.dnf != {}
    has_labels = migrator.json_labels != []
    has_model = migrator.json_model != []
    has_locks = migrator.all_importable_locks != []
    msg = (
        "Image file contains:\n"
        "   project name: {}\n"
        "   input data config: {}\n"
        "   input data: {}\n"
        "   unified dataset config: {}\n"
        "   dnf: {}\n"
        "   pair labels: {}\n"
        "   dedup model: {}\n"
        "   cluster locks: {}\n"
    ).format(
        name, input_cfg, input_data, has_ud_cfg, has_dnf, has_labels,
        has_model, has_locks
    )
    print(msg)

    migrator.migrate_mastering_to(
        create_project=projName not in all_project_names.values(),
        update_source_datasets_def=options.get('INCLUDE_SOURCE_DATA_SCHEMA') and len(input_cfg),
        update_source_data=(
            options.get('INCLUDE_DATA_FILES') and len(input_data),
            options.get('TRUNCATE_OLD_DATA'),
            options.get('TRUNCATE_OLD_DATA')
        ),
        update_unified_dataset_def=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS') and has_ud_cfg,
        update_dnf=options.get('DEDUP_INCLUDE_DNF') and has_dnf,
        update_pair_labels=(
            options.get('DEDUP_INCLUDE_LABELS') and has_labels,
            options.get('DEDUP_DELETE_OLD_LABELS') and has_labels
        ),
        update_model=options.get('DEDUP_INCLUDE_MODEL') and has_model,
        update_locks=(
            options.get('DEDUP_INCLUDE_LOCKS') and has_locks,
            options.get('DEDUP_DELETE_OLD_LOCKS') and has_locks
        ),
        run_pairs=options.get('DEDUP_RUN_PAIRS'),
        run_trainPredictCluster=options.get('DEDUP_RUN_TRAIN_PREDICT_CLUSTER'),
        run_predictCluster=options.get('DEDUP_RUN_PREDICT_CLUSTER')
    )


def import_gr(migrator, options, all_module_names, has_source_list, has_overrides):
    migrator.migrate_gr_to(
        create_module=options.get('NEW_PROJECT_NAME') not in all_module_names.values(),
        replace_source_list=options.get('GR_REPLACE_SOURCE_LIST') and has_source_list,
        replace_overrides=options.get('GR_REPLACE_OVERRIDES') and has_overrides,
        replace_rules=options.get('GR_REPLACE_RULES'),
        update_results=options.get('GR_UPDATE_RESULTS'),
        publish_results=options.get('GR_PUBLISH_RESULTS')
    )


def import_classification(migrator, options, projName, name, input_cfg, input_data, has_ud_cfg):
    taxonomy = migrator.project_dtls.get('taxonomy_name')
    has_manual_categories = migrator.json_labels != []
    msg = (
             "Image file contains:\n"
             "   project name: {}\n"
             "   input data config: {}\n"
             "   input data: {}\n"
             "   unified dataset config: {}\n"
             "   taxonomy name: {}\n"
             "   manual labels: {}\n"
         ).format(name, input_cfg, input_data, has_ud_cfg, taxonomy, has_manual_categories)
    print(msg)

    migrator.migrate_classification_to(
        create_project=projName not in all_project_names.values(),
        update_source_datasets_def=options.get('INCLUDE_SOURCE_DATA_SCHEMA') and len(input_cfg),
        update_source_data=(
            options.get('INCLUDE_DATA_FILES') and len(input_data),
            options.get('TRUNCATE_OLD_DATA'),
            options.get('TRUNCATE_OLD_DATA')
        ),
        update_unified_dataset_def=options.get('INCLUDE_UNIFIED_SCHEMA_AND_TRANSFORMS') and has_ud_cfg,
        update_taxonomy=options.get('CLASS_INCLUDE_TAXONOMY'),
        target_taxonomy_name=options.get('CLASS_NEW_TAXONOMY_NAME'),
        update_categories=options.get('CLASS_INCLUDE_CATEGORIES') and has_manual_categories,
        truncate_old_categories=options.get('CLASS_DELETE_OLD_CATEGORIES')       
         )


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print('usage: python run_migration.py <yaml_file>')
        sys.exit(0)

    with open(sys.argv[1]) as f:
        cfg = yaml.load(f, Loader=yaml.FullLoader)

    # loop over projects to be migrated
    for proj in cfg['PROJECTS']:

        # Check whether we want to export this project, if so, proceed with export
        if proj['FROM_TAMR']['GET_FROM_TAMR'] == 1:
            mig_options = proj.get('FROM_TAMR')
            tamr_conn = mig_options.get('CONNECTION')
            project_name = proj.get('PROJECT_NAME')

            logger('Exporting process')
            # create the migrator from the config values, check to see if can connect using the given creds
            migrator = MigrationClient(tamr_conn.get('HOST'),
                                       tamr_conn.get('PORT'),
                                       tamr_conn.get('USERNAME'),
                                       tamr_conn.get('PASSWORD'))

            # Get project metadata from unify
            logger('Getting metadata from Unify')
            all_projects_info = migrator.tamr.get_all_project_metadata()
            all_projects = {idx: (x['name'], x['type']) for idx, x in enumerate(all_projects_info.json())}
            all_project_names = {idx: x['name'] for idx, x in enumerate(all_projects_info.json())}
            all_modules_info = migrator.tamr.get_all_modules()
            all_modules = {idx + len(all_projects): (x.get('displayName'), x.get('type')) for idx, x in
                           enumerate(all_modules_info)}
            all_module_names = {idx + len(all_projects): x.get('displayName') for idx, x in enumerate(all_modules_info)}

            # get the project by name, checking validity
            project_to_be_migrated = get_valid_project(project_name, all_projects, all_project_names)
            module_to_be_migrated = get_valid_project(project_name, all_modules, all_module_names)
            assert (project_to_be_migrated is not None or module_to_be_migrated is not None), "Project name not found."

            logger('- Exporting project: {}'.format(project_name))

            # Handle the save directory cases - set to Home if nothing provided
            migrator.cfgdir = proj.get('IMAGE_LOCATION') or os.environ.get('HOME')

            # check to make sure the save location is valid
            logger('Checking if the image location folder exists')
            valid_save_location(migrator)

            # define the project type
            projType = project_to_be_migrated[1] if project_to_be_migrated is not None else module_to_be_migrated[1]

            # Apply settings to the migrator function
            # Schema mapping project
            if projType == 'SCHEMA_MAPPING_RECOMMENDATIONS':
                export_schema_mapping(migrator, project_name, mig_options)

            # Mastering project
            elif projType == 'DEDUP':
                export_dedup(migrator, project_name, mig_options)

            elif projType == 'GoldenRecords':
                export_gr(migrator, project_name, mig_options)

            # classification project
            else:
                export_classification(migrator, project_name, mig_options)


        # Check whether we want to import an image, if so, proceed with import
        if proj['TO_TAMR']['UPLOAD_TO_TAMR'] == 1:
            mig_options = proj.get('TO_TAMR')
            tamr_conn = mig_options.get('CONNECTION')
            mig_options['NEW_PROJECT_NAME'] = mig_options.get('NEW_PROJECT_NAME') or proj.get('PROJECT_NAME')

            logger('Importing process')
            # create the migrator from the config values, check to see if can connect using the given creds
            migrator = MigrationClient(tamr_conn.get('HOST'),
                                       tamr_conn.get('PORT'),
                                       tamr_conn.get('USERNAME'),
                                       tamr_conn.get('PASSWORD'))

            migrator.cfgdir = proj['IMAGE_LOCATION'] # can this be linked to pull the same variable from above, if it exists? 

            # Get project metadata from unify
            logger('Getting metadata from Unify')
            all_projects_info = migrator.tamr.get_all_project_metadata()
            all_projects = {idx: (x['name'], x['type']) for idx, x in enumerate(all_projects_info.json())}
            all_project_names = {idx: x['name'] for idx, x in enumerate(all_projects_info.json())}
            all_modules_info = migrator.tamr.get_all_modules()
            all_modules = {idx + len(all_projects): (x.get('displayName'), x.get('type')) for idx, x in
                           enumerate(all_modules_info)}
            all_module_names = {idx + len(all_projects): x.get('displayName') for idx, x in enumerate(all_modules_info)}

            # Read metadata about the image
            logger('Reading metadata from image file')
            projType, name, input_cfg, input_data, has_ud_cfg,\
            projName, has_source_list, has_overrides = read_image_metadata(migrator, mig_options)

            preimport_validation(migrator, mig_options, all_project_names, all_module_names)

            # Extract a schema mapping project
            if projType == 'SCHEMA_MAPPING_RECOMMENDATIONS':
                import_schema_mapping(migrator, mig_options, projName, all_project_names, name, input_cfg, input_data, has_ud_cfg)

            # Mastering Project
            elif projType == 'DEDUP':
                import_dedup(migrator, mig_options, projName, all_project_names, name, input_cfg, input_data, has_ud_cfg)

            # need to add classification!
            elif projType == 'CATEGORIZATION':
                import_classification(migrator, mig_options, projName, name, input_cfg, input_data, has_ud_cfg)

            elif projType == "GOLDEN_RECORDS":
                import_gr(migrator, mig_options, all_module_names, has_source_list, has_overrides)

            shutil.rmtree(os.path.join(migrator.cfgdir, migrator.pkgsubdir))

            logger('Import to Tamr complete')
