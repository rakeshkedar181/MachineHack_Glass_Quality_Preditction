from nltk.tokenize import WordPunctTokenizer
from gensim import corpora
from gensim import models
from gensim import similarities
from collections import defaultdict
import gensim
import config
tk = WordPunctTokenizer() 

def jaccard_similarity(list1, list2):
    intersection = len(list(set(list1).intersection(list2)))
    union = (len(list1) + len(list2)) - intersection
    return float(intersection) / union


def get_similar_doc(query_document, tfidf, dictionary, index):
    
    query_bow = dictionary.doc2bow(query_document)
    sims = index[tfidf[query_bow]]
    return sims


def preprocessing_text(input_text):

    input_words_list = tk.tokenize(input_text)
    clean_input_words_list = []
    for word in input_words_list:
        word = word.lower()
        result = list(filter(lambda x: x.isalpha(), word))
        word = ''.join(result)

        if word not in clean_input_words_list and len(word) > 2 :
            clean_input_words_list.append(word)

    return clean_input_words_list


def create_index(text_corpus) :

    frequency = defaultdict(int)
    for text in text_corpus:
        for token in text:
            frequency[token] += 1

    # Only keep words that appear more than once

    processed_corpus = [[token for token in text if frequency[token] > 1] for text in text_corpus]

    # creating dictonary from corpus
    dictionary = corpora.Dictionary(processed_corpus)
    
    # creating bow
    bow_corpus = [dictionary.doc2bow(text) for text in processed_corpus]

    # train the model
    tfidf = models.TfidfModel(bow_corpus,normalize=True,slope=1)

    index = similarities.SparseMatrixSimilarity(tfidf[bow_corpus], num_features=len(bow_corpus), num_best=10)
    return index, dictionary, tfidf


def create_or_load_indexes(filtered_df, brand_name_raw):

    try :
        # log.info("LOADING INDEX FOR {}".format(brand_name_raw))
        dictionary_brand = gensim.corpora.Dictionary.load(config.DICTONARY_FILE_PATH.format(brand_name_raw))
        tfidf_brand = gensim.models.TfidfModel.load(config.TFIDF_MODEL_PATH.format(brand_name_raw))
        index_brand = similarities.SparseMatrixSimilarity.load(config.INDEX_FILE_PATH.format(brand_name_raw))
        # log.info("Successfully loaded INDEX FOR {}".format(brand_name_raw))

    except Exception as e:
        # log.info("Creating INDEX FOR {}".format(brand_name_raw))
        text_corpus_brand = filtered_df['clean_brand_desc'].tolist()
        index_brand, dictionary_brand, tfidf_brand = create_index(text_corpus_brand)
        index_brand.save(config.INDEX_FILE_PATH.format(brand_name_raw))
        dictionary_brand.save(config.DICTONARY_FILE_PATH.format(brand_name_raw))
        tfidf_brand.save(config.TFIDF_MODEL_PATH.format(brand_name_raw))

    return dictionary_brand, tfidf_brand, index_brand



def cosine_similarity_of_data(query_document, filtered_df, tfidf_brand, dictionary_brand, index_brand):

    cosine_score = {}
    sims_brand = get_similar_doc(query_document, tfidf_brand, dictionary_brand, index_brand)
    if sims_brand == []:
        # import sys
        # sys.exit()
        print("*********************Need to check with all data not just brand data")
        dictionary_brand, tfidf_brand, index_brand = create_or_load_indexes(filtered_df, 'all')
        # cosine_score = cosine_similarity_of_data(query_doc, filtered_df, tfidf_brand, dictionary_brand, index_brand)
        sims_brand = get_similar_doc(query_document, tfidf_brand, dictionary_brand, index_brand)

    for document_number, score in sorted(enumerate(sims_brand), key=lambda x: x[1][1], reverse=True)[:1]:

        document_number = score[0]
        # print("Match in Brand Sheet is : ",filtered_df.iloc[document_number]['material_name'], "Score is : ", score[1])
        # print("\n",filtered_df.iloc[document_number]['gcph_brand'],"-",brand_name)
    
        cosine_score = [(document_number,score[1])]
    # print(cosine_score)
    return cosine_score 

def get_jaccard_score(query_doc, filtered_df):

    jaccard_score = {}
    for index, item in filtered_df.iterrows():
        score = jaccard_similarity(item['clean_brand_desc'], query_doc)
        jaccard_score.update({index :score })

    jaccard_score = sorted(jaccard_score.items(), key=lambda kv: kv[1], reverse=True)[:1]

    return jaccard_score