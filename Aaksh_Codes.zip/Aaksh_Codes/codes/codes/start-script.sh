#!/bin/bash

rm -f /home/agouda2/python_codes/codes/nohup.out
. /home/agouda2/tamr-python/venv/bin/activate
cd /home/agouda2/python_codes/codes
nohup python start_python_matching.py &
