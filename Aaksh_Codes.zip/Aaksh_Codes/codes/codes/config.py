# key : input file market , value : region of product hierarchy file
market_region_mapping = {'ca':'ca', 'us':'usa', 'de':'emea', 'uk':'emea'}

# key : brand in input file, value : corresponding gcph brand
mapping_dict = {
"acuvue":"All Other GFO Brand",
"aveeno2":"Aveeno",
"bandaid":"Band Aid",
"benylin":"Benylin",
"helpthemquit":"all",
"lispro":"Listerine",
"lpm":"Le Petit Marseillais",
"motrin":"Motrin",
"nicoderm":"Nicoderm",
"pepcid":"Pepcid",
"sudafed":"Sudafed",
"visine":"Visine / Vispring / Visclear",
"polysporin" : "Polysporin",
"neutrogena" : "Neutrogena",
"cnc" : "Clean & Clear",
"jbaby3" : "Johnsons Baby",
'jbaby' : "Johnson's Baby",
'imodium': 'Imodium',
'tylenol' : 'Tylenol',
'lis' : "Listerine",
'nicorette' : "Nicorette",
'benadryl' : 'Benadryl',
'reactine' : 'Reactine',
'penaten' : 'Penaten',
'microlax' : 'Microlax/Micralax',
'rogaine' : 'Rogaine / Regaine',
'aveenomd' : 'Aveeno',
'lactaid' : 'Lactaid',
'bengay' : 'Bengay',
'desitin' : 'Desitin',
'zyrtec' : 'Zyrtec',
'neosporin' : 'Neosporin',
'blink' : 'All Other Self Care Brand',
'rhinocort' : 'Rhinocort/ Pulmicort',
'regaine' : 'Rogaine / Regaine',
'blinkexpert' : 'All Other Self Care Brand',
'brandhub' : 'all',
'livocab' : 'Livocab',
'olynth' : 'Olynth',
"carefree" : "Carefree",
"hexoral" : "Hexoral",
}

# GCS Config 
GCS_BUCKET_NAME='itx-agj-cons-pdp-data'


# s3 secret file
CREDENTIALS_FILE_PATH = '../credentials/auth.yaml'

# Stroring brand wise model
BRAND_INDEX_DIRECTORY = '../brand_model'
DICTONARY_FILE_PATH = '../brand_model/{}_dictionary_brand'
TFIDF_MODEL_PATH = '../brand_model/{}_tfidf_brand'
INDEX_FILE_PATH = '../brand_model/{}_index_brand'

# S3 bucket name
S3_BUCKET_NAME ='itx-agj-cons-pdp-data'

# Loading product hierarchy csv file 
def get_product_hierarchy_file(REGION):
    PRODUCT_HIERARCHY_FILE = '../data/input_data/{}_product_hierarchy.csv'.format(REGION)
    return PRODUCT_HIERARCHY_FILE

# Loading input file for prediction
def get_input_filename(MARKET, date_string):
    INPUT_FILE_NAME = 'pdp_product_hierarchy_mapping_{}_{}.csv'.format(MARKET, date_string)
    return INPUT_FILE_NAME

# Loading input file for prediction
def get_input_filepath(INPUT_FILE_NAME):
    INPUT_FILE_FILEPATH = '../data/input_data/{}'.format(INPUT_FILE_NAME)
    return INPUT_FILE_FILEPATH

# Output file name 
def get_output_filename(MARKET, date_string):
    OUTPUT_FILENAME = "python_ts_output_{}_{}.csv".format(MARKET, date_string)
    return OUTPUT_FILENAME

# Output file path
def get_output_filepath(OUTPUT_FILENAME):
    OUTPUT_FILEPATH = '../data/output_data/{}'.format(OUTPUT_FILENAME)
    return OUTPUT_FILEPATH


product_hierarchy_file_query = """SELECT * FROM `jjt-consumerdatalake-bigquery.ga360_analytics.redshift_sdi_product_hierarchy` where region='{}'"""

product_hierarchy_output_folder = '../data/input_data/{}'

regions_to_download_filename_dict = {'CA':'ca_product_hierarchy.csv', 'USA' : 'usa_product_hierarchy.csv', 'EMEA' : 'emea_product_hierarchy.csv'}