import pandas as pd
import os
import shutil
import config
import logging
import nlp_functions
import auto_download_upload_gcp
import yaml
import sys
import common_utils
import datetime
from textblob import TextBlob
from googletrans import Translator
import creating_product_hierarchy_file
from os import listdir
import pandas as pd


# Initalizing Logger
logging.basicConfig(filename = '../logs/python_process.log', format='%(asctime)s.%(msecs)03d %(levelname)s {%(module)s} [%(funcName)s] %(message)s', datefmt='%Y-%m-%d,%H:%M:%S', level=logging.INFO)
log = logging.getLogger(__file__)

# This items remain same from input file
def common_data_to_retain(item):
    new_row = {}
    new_row.update({'brand' :item['brand'],
    'market' : item['market'],
    'page_title' : item['page_title'],
    'page_url' : item['page_url'],
    'product_id' : item['product_id'],
    'product_name' : item['product_name'],
    'sku' : item['sku'],
    'match_type' : item['match_type'],
    'material_number' : item['material_number'],
    'ean_upc' : item['ean_upc'],
    'material_name' : item['material_name'],
    })

    return new_row


# old gcph predictions
def data_to_retain_if_match(item, new_row):

    new_row.update({
    'gcph_gfo' : item['gcph_gfo'],
    'gcph_brand' : item['gcph_brand'],
    'region' : item['region'],
    'gcph_subbrand' : item['gcph_subbrand'],
    'gcph_varient' : item['gcph_varient'],
    'gcph_needstate' : item['gcph_needstate'],
    'gcph_category' : item['gcph_category'],
    'gcph_subcategory' : item['gcph_subcategory'],
    'gcph_segment' : item['gcph_segment'],
    'gcph_subsegment' : item['gcph_subsegment']
    })

    return new_row


# new gcph predictions
def update_data_on_prediction(new_row, output_df, score, type_of_match):

    new_row.update({
    "score" : score,
    "type_of_match" : type_of_match,
    "match_product_desc" : output_df['material_name'],
    'gcph_gfo' : output_df['gcph_gfo'],
    'gcph_brand' : output_df['gcph_brand'],
    'region' : output_df['region'],
    'gcph_subbrand' : output_df['gcph_subbrand'],
    'gcph_varient' : output_df['gcph_varient'],
    'gcph_needstate' : output_df['gcph_needstate'],
    'gcph_category' : output_df['gcph_category'],
    'gcph_subcategory' : output_df['gcph_subcategory'],
    'gcph_segment' : output_df['gcph_segment'],
    'gcph_subsegment' : output_df['gcph_subsegment']
    })

    return new_row


def start_no_match_predictions(query, prodict_hierarchy_df, brand_name_raw, new_row):
    filtered_df, type_of_index = common_utils.brand_wise_filter(prodict_hierarchy_df, brand_name_raw)    
    query_doc = nlp_functions.preprocessing_text(query)
    # print("INDEX TYPE Is ", type_of_index)
    score = 0
    type_of_match = ''
    if type_of_index == 'jaccard':
        jaccard_score = nlp_functions.get_jaccard_score(query_doc, filtered_df)
        if jaccard_score == []:
            new_row.update({
                "match_product_desc" : '',
                'gcph_gfo' : '',
                'gcph_brand' : '',
                'region' : '',
                'gcph_subbrand' : '',
                'gcph_varient' : '',
                'gcph_needstate' : '',
                'gcph_category' : '',
                'gcph_subcategory' : '',
                'gcph_segment' : '',
                'gcph_subsegment' : ''
                })
            return new_row

        key = jaccard_score[0][0]
        score = jaccard_score[0][1]
        type_of_match = type_of_index
        output_df = filtered_df.loc[key]
        # print(output_df['gcph_gfo'],output_df['gcph_brand'],output_df['gcph_subbrand'],output_df['gcph_varient'],output_df['gcph_needstate'],output_df['gcph_category'],output_df['gcph_subcategory'],output_df['gcph_segment'],output_df['gcph_subsegment'])
    else : 
        dictionary_brand, tfidf_brand, index_brand = nlp_functions.create_or_load_indexes(filtered_df, brand_name_raw)
        cosine_score = nlp_functions.cosine_similarity_of_data(query_doc, filtered_df, tfidf_brand, dictionary_brand, index_brand)
        
        if cosine_score == {}:
            new_row.update({
                "match_product_desc" : '',
                'gcph_gfo' : '',
                'gcph_brand' : '',
                'region' : '',
                'gcph_subbrand' : '',
                'gcph_varient' : '',
                'gcph_needstate' : '',
                'gcph_category' : '',
                'gcph_subcategory' : '',
                'gcph_segment' : '',
                'gcph_subsegment' : ''
                })
            return new_row
            
        else:
            key = cosine_score[0][0]
            score = cosine_score[0][1]
            type_of_match = type_of_index
            output_df = filtered_df.iloc[key]
            # print(output_df['gcph_gfo'],output_df['gcph_brand'],output_df['gcph_subbrand'],output_df['gcph_varient'],output_df['gcph_needstate'],output_df['gcph_category'],output_df['gcph_subcategory'],output_df['gcph_segment'],output_df['gcph_subsegment'])
        
    new_row = update_data_on_prediction(new_row, output_df, score, type_of_match)

    return new_row


if __name__ == "__main__":
    logging.getLogger().setLevel(logging.WARN)
    translator = Translator()

    date_string = datetime.datetime.now().strftime("%Y%m%d")
    print(date_string)
    date_string = '20201106'


    # getting credentials 
    msg = "Loading Credentials"
    log.info(msg)
    print(msg)
    try : 
        with open(config.CREDENTIALS_FILE_PATH) as f: # replace with your credentials.yaml path
            creds = yaml.safe_load(f)
    except Exception as e:
        msg = "FAILED !!! loading credentailas {}".format(config.CREDENTIALS_FILE_PATH)
        log.error(e)
        print(msg)
        sys.exit()
        
    log.info("==== Credentials loaded successfully. ==== ")

    # Fetching Data from s3
    msg = "==== Starting AutoDownload script ==== "
    log.info(msg)
    print(msg)
    try:
        gcs_client = auto_download_upload_gcp.get_gcs_client()
        # Starting download of product hierarchy file 
        creating_product_hierarchy_file.create_product_hierarchy_file()
        MARKET_LIST = auto_download_upload_gcp.get_current_dates_data(gcs_client, date_string)

        log.info("==== Created S3 client ==== ")

    except Exception as e:
        msg = "Auto Download Script Failed !!!"
        log.error(e)
        print(msg)
        sys.exit()
        
    for market in MARKET_LIST:

        auto_download_upload_gcp.download_file_from_gcs(gcs_client, date_string, market)
        log.info("==== File download complete ==== ")

        # Fetching Data from s3
        msg = "==== Starting Truncate brand folder script ==== "
        log.info(msg)
        print(msg)
        try:
            common_utils.truncate_model_directory()
        except Exception as e:
            msg = "Truncate Script Failed !!!"
            log.error(e)
            print(msg)
            sys.exit()
        
        msg = "==== Starting INput and Product hierarchy file load ==== "
        log.info(msg)
        print(msg)
        try:
            INPUT_FILE_NAME = config.get_input_filename(market, date_string)
            INPUT_FILE_FILEPATH = config.get_input_filepath(INPUT_FILE_NAME)
            df2 = common_utils.load_test_data(INPUT_FILE_FILEPATH)
            REGION = config.market_region_mapping.get(market) 
            PRODUCT_HIERARCHY_FILE = config.get_product_hierarchy_file(REGION)
            prodict_hierarchy_df = common_utils.load_product_file(PRODUCT_HIERARCHY_FILE)
        except Exception as e:
            msg = "INput and Product hierarchy file load Failed !!!"
            log.error(e)
            print(msg)
            sys.exit()

        msg = "==== Starting Prediction of no match data ==== "
        log.info(msg)
        print(msg)
        try:
            final_list = []
            for index, item in df2.iterrows():
                new_row = {}
                brand_name_raw = item['brand']
                query = item['brand_desc']
                print("QUERY === >>", query)
                new_row = common_data_to_retain(item)

                if item['match_type'] != 'no_match':
                    new_row = data_to_retain_if_match(item, new_row)

                else:
                    if market == 'ca':
                        # print(translator.translate(query).text)
                        query = translator.translate(query).text
                        print("\tTRANSLATED  = > ",query)
                    new_row = start_no_match_predictions(query, prodict_hierarchy_df, brand_name_raw, new_row)
            
                final_list.append(new_row)

        except Exception as e:
            msg = "Prediction of no match data  Failed !!!"
            log.error(e)
            print(msg)
            sys.exit()

        msg = "==== Starting Upload of Python output to s3 ==== "
        log.info(msg)
        print(msg)
        try:
            OUTPUT_FILENAME =  config.get_output_filename(market, date_string)
            OUTPUT_FILEPATH = config.get_output_filepath(OUTPUT_FILENAME)
            common_utils.write_final_output_to_csv(final_list, OUTPUT_FILEPATH)
            log.info("Starting Upload of file to GCS")
            # Put data into s3
            auto_download_upload_gcp.upload_file_to_gcs(gcs_client, market, date_string)
            log.info("Successfull !!! Upload of file to GCS")
        except Exception as e:
            msg = "Upload of file to GCS Failed !!!"
            log.error(e)
            print(msg)

    if len(MARKET_LIST) > 0:
        auto_download_upload_gcp.upload_success_file(gcs_client, date_string)

        # Starting merge of all csv files and renaming it to ga dimensions.
        filepaths = []
        for market in MARKET_LIST:
            OUTPUT_FILENAME = config.get_output_filename(market, date_string)
            filepaths.append(config.get_output_filepath)

        df = pd.concat(map(pd.read_csv, filepaths))


        old_mappings = {
        "product_id": "ga:productSku",
        "region": "ga:dimension60",
        "gcph_gfo": "ga:dimension61",
        "gcph_brand": "ga:productBrand",
        "gcph_subbrand": "ga:dimension62",
        "gcph_varient": "ga:productVariant",
        "gcph_needstate": "ga:dimension63",
        "gcph_category": "ga:productCategoryHierarchy",
        "gcph_subcategory": "ga:dimension64",
        "gcph_segment": "ga:dimension65",
        "gcph_subsegment": "ga:dimension66",
        }

        df = df[['product_id', 'region', 'gcph_gfo', 'gcph_brand', 'gcph_subbrand', 'gcph_varient', 'gcph_needstate', 'gcph_category', 'gcph_subcategory', 'gcph_segment', 'gcph_subsegment']]
        df= df.rename(columns=old_mappings)
        df.to_csv('../data/output_data/ga360_Product_File.csv', index=False, header=True)
