import config
import datetime
import os
import logging
import yaml
import config 
import sys
from google.cloud import storage


log = logging.getLogger(__file__)


def upload_file_to_gcs(storage_client, market, date_string):
    """Upload a file to an S3 bucket

    :param s3_client: s3 client object
    """

    bucket_name = config.GCS_BUCKET_NAME
    OUTPUT_FILENAME = config.get_output_filename(market, date_string)
    file_name = "python_output/{}/{}/{}".format(date_string, market, OUTPUT_FILENAME)
    destination_blob_name = file_name
    source_file_name = config.get_output_filepath(OUTPUT_FILENAME)
    try:

        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_name)

        print(
            "File {} uploaded to {}.".format(
                source_file_name, destination_blob_name
            )
        )
    except Exception as e:
        log.error(e)
        print(e)


def upload_success_file(storage_client, date_string):

    bucket_name = config.GCS_BUCKET_NAME
    file_name = "python_output/{}/{}".format(date_string, '_SUCCESS')
    file_to_write = '../data/_SUCCESS'
    destination_blob_name = file_name
    source_file_name = file_to_write
    try:

        bucket = storage_client.bucket(bucket_name)
        blob = bucket.blob(destination_blob_name)

        blob.upload_from_filename(source_file_name)

        print(
            "File {} uploaded to {}.".format(
                source_file_name, destination_blob_name
            )
        )
        msg = "Successfull !!! Upload of File  {} ".format(file_to_write)
        log.info(msg)
        print(msg)

    except Exception as e:
        log.error(e)
        print(e)
        sys.exit()


def download_file_from_gcs(gcs_client, date_string, MARKET):
    """Download file from s3 folder

    Args:
        s3_client ([s3_obj]): [description]
    """
    
    log.info("Starting Download of File from S3")
    # URL =  "s3://itx-agj-cons-pdp-data/tamr_input/pdp_product_hierarchy_mapping_20200626.csv"

    try:
        
        INPUT_FILE_NAME = config.get_input_filename(MARKET, date_string)
        #GCS_tamr_input_path = 'tamr_input/{}/{}/{}'.format(date_string, MARKET, INPUT_FILE_NAME)
        GCS_tamr_input_path = 'python_sim_input/{}/{}/{}'.format(date_string, MARKET, INPUT_FILE_NAME)
        INPUT_FILE_FILEPATH = config.get_input_filepath(INPUT_FILE_NAME)
        bucket_name = config.GCS_BUCKET_NAME
        source_blob_name = GCS_tamr_input_path
        destination_file_name = INPUT_FILE_FILEPATH
        bucket = gcs_client.bucket(bucket_name)
        blob = bucket.blob(source_blob_name)
        blob.download_to_filename(destination_file_name)

        print(
            "Blob {} downloaded to {}.".format(
                source_blob_name, destination_file_name
            )
        )
        
    except Exception as e:
        print("Exception is ", e)
        log.error("FAILED !!!! Download of File  {}  from Bucket {}".format(GCS_tamr_input_path, bucket))
        sys.exit()


def get_gcs_client():

    try:
        gcs_client = storage.Client()

        return gcs_client

    except Exception as e:
        print(e)
        log.exception(e)
        sys.exit()


def get_current_dates_data(gcs_client, date_string):
    MARKET_LIST = []
    bucket_name = config.GCS_BUCKET_NAME
    bucket = gcs_client.get_bucket(bucket_name)
    # PREFIX_PATH = "tamr_input/{}".format(date_string)
    PREFIX_PATH = "python_sim_input/{}".format(date_string)
    blobs = bucket.list_blobs(prefix=PREFIX_PATH)

    for blob in blobs:
        print(blob.name)
        files = blob.name
        print(files.split('/')[2])
        MARKET_LIST.append(files.split('/')[2])    
    
    return MARKET_LIST


if __name__ == "__main__":
    date_string = '20200805'
    with open("../credentials/auth.yaml") as f: # replace with your credentials.yaml path
        creds = yaml.safe_load(f)
    gcs_client = get_gcs_client()
    upload_success_file(gcs_client, date_string)
