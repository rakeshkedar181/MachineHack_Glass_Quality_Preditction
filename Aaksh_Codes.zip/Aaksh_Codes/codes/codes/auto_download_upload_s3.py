import config
import datetime
import os
import logging
import yaml
import config 
import sys
import boto3
import botocore

log = logging.getLogger(__file__)


def upload_file(s3_client, market, date_string, object_name=None):
    """Upload a file to an S3 bucket

    :param s3_client: s3 client object
    """

    bucket = config.S3_BUCKET_NAME
    OUTPUT_FILENAME = config.get_output_filename(market, date_string)
    file_name = "python_output/{}/{}/{}".format(date_string, market, OUTPUT_FILENAME)

    log.info("Starting Upload of File  {}  from Bucket {}".format(file_name, bucket))
    object_name = file_name

    OUTPUT_FILEPATH = config.get_output_filepath(OUTPUT_FILENAME)
    file_to_write = OUTPUT_FILEPATH

    try:
        s3_client.upload_file(file_to_write, bucket, object_name)
        msg = "Successfull !!! Upload of File  {} ".format(file_to_write)
        log.info(msg)
        print(msg)
    except Exception as e:
        log.error(e)
        print(e)
        sys.exit()


def upload_success_file(s3_client, date_string, object_name=None):

    bucket = config.S3_BUCKET_NAME
    file_name = "tamr_output/{}/{}".format(date_string, '_SUCCESS')
    object_name = file_name
    file_to_write = '../data/_SUCCESS'

    try:
        s3_client.upload_file(file_to_write, bucket, object_name)
        msg = "Successfull !!! Upload of File  {} ".format(file_to_write)
        log.info(msg)
        print(msg)
    except Exception as e:
        log.error(e)
        print(e)
        sys.exit()


def download_file_from_s3(s3_client, date_string, MARKET):
    """Download file from s3 folder

    Args:
        s3_client ([s3_obj]): [description]
    """
    
    log.info("Starting Download of File from S3")
    # URL =  "s3://itx-agj-cons-pdp-data/tamr_input/pdp_product_hierarchy_mapping_20200626.csv"

    bucket = config.S3_BUCKET_NAME
    # date_string = config.date_string
    INPUT_FILE_NAME = config.get_input_filename(MARKET, date_string)
    file_to_read = "tamr_input/{}/{}/{}".format(date_string, MARKET, INPUT_FILE_NAME)

    log.info("Starting Download of File  {}  from Bucket {}".format(file_to_read, bucket))
    INPUT_FILE_FILEPATH = config.get_input_filepath(INPUT_FILE_NAME)
    file_to_write = INPUT_FILE_FILEPATH

    try:
        # s3.Bucket(bucket).download_file(file, os.path.basename(file))
        s3_client.download_file(bucket, file_to_read ,file_to_write)
        log.info("Successfull !!! Download of File  {} ".format(file_to_write))
        
    except Exception as e:
        print("Exception is ", e)
        log.error("FAILED !!!! Download of File  {}  from Bucket {}".format(file_to_read, bucket))
        if e.response['Error']['Code'] == "404":
            print("The object does not exist.")
        else:
            raise
        sys.exit()


def get_s3_client(creds):
    """Create s3 client

    Args:
        creds ([dict]): [access_key and secret key]

    Returns:
        [s3_client]: [s3_client]
    """
    try:
        s3_client = boto3.client('s3', 
                    aws_access_key_id=creds['s3_access_key'], 
                    aws_secret_access_key=creds['s3_secret_key'], 
                    )
        return s3_client

    except Exception as e:
        print(e)
        log.exception(e)
        sys.exit()



def get_current_dates_data(s3_client, date_string):
    MARKET_LIST = []
    resp = s3_client.list_objects(Bucket=config.S3_BUCKET_NAME, Prefix='tamr_input/{}'.format(date_string))
    for obj in resp['Contents']:
        files = obj['Key']
        print(files.split('/')[2])
        MARKET_LIST.append(files.split('/')[2])
    
    return MARKET_LIST


if __name__ == "__main__":

    with open("../credentials/auth.yaml") as f: # replace with your credentials.yaml path
        creds = yaml.safe_load(f)
    
    s3_client = get_s3_client(creds)
    upload_file(s3_client)