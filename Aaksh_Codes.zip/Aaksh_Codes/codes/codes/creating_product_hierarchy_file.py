import common_utils
import google.auth
from google.cloud import bigquery
from google.cloud import bigquery_storage_v1beta1
import config

def create_product_hierarchy_file():
    bqclient, bqstorageclient = common_utils.get_bq_connection()
    regions_to_download_filename_dict = config.regions_to_download_filename_dict

    for region, filename in regions_to_download_filename_dict.items():
        output_dir = config.product_hierarchy_output_folder.format(filename)
        query_string = config.product_hierarchy_file_query.format(region)
        print("Executing Query for region : \n ",query_string)
        df = (
        bqclient.query(query_string)
        .result()
        .to_dataframe(bqstorage_client=bqstorageclient)
        )

        df.to_csv(output_dir, index=False, header=True)


if __name__ == "__main__":
    create_product_hierarchy_file()




