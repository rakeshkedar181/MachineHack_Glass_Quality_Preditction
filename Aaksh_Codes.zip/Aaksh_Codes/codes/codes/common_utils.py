import config
import logging
import pandas as pd
import os
import shutil
import sys
import nlp_functions
from google.cloud import bigquery
from google.cloud import bigquery_storage_v1beta1
import google.auth
import config
import logging
log = logging.getLogger(__file__)

def truncate_model_directory():
    """
    Delete the directory and recreate one
    """
    msg = "Starting Delete of model folder {}".format(config.BRAND_INDEX_DIRECTORY)
    log.info(msg)
    print(msg)
    try:
        shutil.rmtree(config.BRAND_INDEX_DIRECTORY, ignore_errors=True)

        msg = "Starting creation of folder {}".format(config.BRAND_INDEX_DIRECTORY)
        log.info(msg)
        print(msg)
        os.mkdir(config.BRAND_INDEX_DIRECTORY)

    except Exception as e:
        msg = "FAILED !!! creation of folder {}".format(config.BRAND_INDEX_DIRECTORY)
        log.error(e)
        print(msg)
        sys.exit()
        

def brand_wise_filter(df, brand_name_raw):
    """[summary]
    Filter Product hierarchy file with the brand name
    Args:
        df ([dataframe]): [Product hierarchy file dataframe]
        brand_name_raw ([string]): [brand name]

    Returns:
        [dataframe, string]: [filterdf, type of sim jaccard or cosine]
    """
    brand_name = config.mapping_dict.get(brand_name_raw, 'all')
    #brand_name = config.mapping_dict.get(brand_name_raw)
    if brand_name != 'all':
        filtered_df = df.loc[df['gcph_brand'] == brand_name]
        type_of_index = 'cosine'

        if len(filtered_df) < 30:
            type_of_index = 'jaccard'

    else:
        filtered_df = df
        type_of_index = 'cosine'
    
    return filtered_df, type_of_index


def load_test_data(INPUT_FILE_FILEPATH):
    """Loading the file on which prediction is to be done

    Returns:
        [dataframe]: [csv loaded as dataframe]
    """
    df2 = pd.read_csv(INPUT_FILE_FILEPATH)
    df2['brand_desc'] = df2['product_name']+' '+df2['brand']
    df2.sort_values("brand", axis = 0, ascending = True, 
                    inplace = True, na_position ='last')
    df2.dropna(subset=['brand_desc'],axis=0, inplace=True)

    return df2

def load_product_file(PRODUCT_HIERARCHY_FILE):
    """Loading product hierarchy file

    Returns:
        [dataframe]: [product hierarchy csv loaded as dataframe]
    """
    df = pd.read_csv(PRODUCT_HIERARCHY_FILE)
    df.dropna(subset=['material_name'],axis=0, inplace=True)
    df['clean_brand_desc'] = df['material_name'].apply(lambda x: nlp_functions.preprocessing_text(x))
    df.dropna(subset=['gcph_brand'],axis=0, inplace=True)

    return df


def write_final_output_to_csv(final_list, OUTPUT_FILEPATH):
    df3 = pd.DataFrame(final_list)
    df3 = df3[['brand','market','page_title','page_url','product_id','product_name','sku','match_type','material_number','ean_upc','material_name','score','type_of_match','match_product_desc','gcph_gfo','gcph_brand','region','gcph_subbrand','gcph_varient','gcph_needstate','gcph_category','gcph_subcategory','gcph_segment','gcph_subsegment' ]]
    df3.to_csv(OUTPUT_FILEPATH, header=True, index=False)


def get_bq_connection():
    credentials, your_project_id = google.auth.default(
        scopes=["https://www.googleapis.com/auth/cloud-platform"]
    )

    # Make clients.
    bqclient = bigquery.Client(credentials=credentials, project=your_project_id,)
    bqstorageclient = bigquery_storage_v1beta1.BigQueryStorageClient(
        credentials=credentials
    )

    return bqclient, bqstorageclient
